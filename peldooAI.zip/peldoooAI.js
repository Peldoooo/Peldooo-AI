let apiKey = '';
let personality = '';
let chatHistory = [];
let currentUser = null;

// Load users from localStorage
function loadUsers() {
    return JSON.parse(localStorage.getItem('users')) || {};
}

// Save users to localStorage
function saveUsers(users) {
    localStorage.setItem('users', JSON.stringify(users));
}

// Load chat history for a user from localStorage
function loadChatHistory(username) {
    const histories = JSON.parse(localStorage.getItem('chatHistories')) || {};
    return histories[username] || [];
}

// Save chat history for a user to localStorage
function saveChatHistory(username, history) {
    const histories = JSON.parse(localStorage.getItem('chatHistories')) || {};
    histories[username] = history;
    localStorage.setItem('chatHistories', JSON.stringify(histories));
}

// Load personality for a user from localStorage
function loadPersonality(username) {
    const personalities = JSON.parse(localStorage.getItem('personalities')) || {};
    return personalities[username] || '';
}

// Save personality for a user to localStorage
function savePersonality(username, newPersonality) {
    const personalities = JSON.parse(localStorage.getItem('personalities')) || {};
    personalities[username] = newPersonality;
    localStorage.setItem('personalities', JSON.stringify(personalities));
}

// Simple analysis to adjust personality based on user input
function analyzeAndUpdatePersonality(userInput, currentPersonality) {
    let updatedPersonality = currentPersonality;
    
    // Basic keyword-based analysis
    const lowerInput = userInput.toLowerCase();
    if (lowerInput.includes('obrigado') || lowerInput.includes('agradeço')) {
        updatedPersonality += ' Você é gentil e aprecia feedback positivo.';
    }
    if (lowerInput.includes('rápido') || lowerInput.includes('urgente')) {
        updatedPersonality += ' Você responde de forma concisa e direta.';
    }
    if (lowerInput.includes('detalhado') || lowerInput.includes('explicar')) {
        updatedPersonality += ' Você fornece respostas detalhadas e completas.';
    }
    if (lowerInput.includes('engraçado') || lowerInput.includes('piada')) {
        updatedPersonality += ' Você usa um tom humorístico quando apropriado.';
    }
    
    // Limit personality length to avoid excessive growth
    if (updatedPersonality.length > 500) {
        updatedPersonality = updatedPersonality.slice(-500);
    }
    
    return updatedPersonality;
}

// Register button event
document.getElementById('registerBtn').addEventListener('click', () => {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const errorEl = document.getElementById('loginError');
    
    if (!username || !password) {
        errorEl.textContent = 'Please enter both username and password.';
        return;
    }
    
    const users = loadUsers();
    if (users[username]) {
        errorEl.textContent = 'Username already exists.';
        return;
    }
    
    users[username] = password;
    saveUsers(users);
    errorEl.textContent = 'Registered successfully! Please log in.';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
});

// Login button event
document.getElementById('loginBtn').addEventListener('click', () => {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const errorEl = document.getElementById('loginError');
    
    if (!username || !password) {
        errorEl.textContent = 'Please enter both username and password.';
        return;
    }
    
    const users = loadUsers();
    if (users[username] && users[username] === password) {
        currentUser = username;
        document.getElementById('login').style.display = 'none';
        document.getElementById('settings').style.display = 'block';
        document.getElementById('currentUser').textContent = username;
        
        // Load and display chat history
        chatHistory = loadChatHistory(username);
        chatHistory.forEach(msg => addMessage(msg.role === 'user' ? 'user' : 'ai', msg.content));
        
        // Load and display personality
        personality = loadPersonality(username);
        document.getElementById('personality').value = personality;
        document.getElementById('currentPersonality').textContent = personality ? `Current Personality: ${personality}` : '';
    } else {
        errorEl.textContent = 'Invalid username or password.';
    }
});

// Save settings button event
document.getElementById('saveSettings').addEventListener('click', () => {
    apiKey = document.getElementById('apiKey').value.trim();
    personality = document.getElementById('personality').value.trim();
    
    if (!apiKey || !personality) {
        alert('Please enter both API key and personality.');
        return;
    }
    
    if (currentUser) {
        savePersonality(currentUser, personality);
    }
    
    document.getElementById('settings').style.display = 'none';
    document.getElementById('chatContainer').style.display = 'block';
});

// Logout button event
document.getElementById('logoutBtn').addEventListener('click', () => {
    if (currentUser) {
        saveChatHistory(currentUser, chatHistory);
        savePersonality(currentUser, personality);
    }
    
    apiKey = '';
    personality = '';
    chatHistory = [];
    currentUser = null;
    document.getElementById('chatBox').innerHTML = '';
    document.getElementById('chatContainer').style.display = 'none';
    document.getElementById('settings').style.display = 'none';
    document.getElementById('login').style.display = 'block';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('apiKey').value = '';
    document.getElementById('personality').value = '';
    document.getElementById('loginError').textContent = '';
    document.getElementById('currentPersonality').textContent = '';
});

// Send message button event
document.getElementById('sendBtn').addEventListener('click', sendMessage);
document.getElementById('userInput').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

function sendMessage() {
    const userInput = document.getElementById('userInput').value.trim();
    if (!userInput) return;
    
    addMessage('user', userInput);
    document.getElementById('userInput').value = '';
    
    chatHistory.push({ role: 'user', content: userInput });
    
    // Update personality based on user input
    personality = analyzeAndUpdatePersonality(userInput, personality);
    if (currentUser) {
        savePersonality(currentUser, personality);
        document.getElementById('currentPersonality').textContent = `Current Personality: ${personality}`;
    }
    
    fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`,
            'HTTP-Referer': window.location.href,
            'X-Title': 'AI Chat Interface'
        },
        body: JSON.stringify({
            model: 'cognitivecomputations/dolphin-mistral-24b-venice-edition:free',
            messages: [
                { role: 'system', content: personality },
                ...chatHistory
            ]
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        const aiResponse = data.choices[0].message.content;
        addMessage('ai', aiResponse);
        chatHistory.push({ role: 'assistant', content: aiResponse });
        if (currentUser) {
            saveChatHistory(currentUser, chatHistory);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        addMessage('ai', 'Sorry, there was an error. Check your API key or try again later.');
        chatHistory.push({ role: 'assistant', content: 'Error: Unable to get AI response.' });
        if (currentUser) {
            saveChatHistory(currentUser, chatHistory);
        }
    });
}

function addMessage(sender, text) {
    const chatBox = document.getElementById('chatBox');
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', sender);
    messageDiv.textContent = text;
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
}

